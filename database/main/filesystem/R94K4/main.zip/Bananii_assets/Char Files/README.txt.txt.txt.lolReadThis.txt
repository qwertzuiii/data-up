Normal People way:
Put "PutThisIntoMainFolder" into the main folder (lol) (there, where the .exe is).
	-> THEN you extract this zip and BOOOM you have my char files...

Alternative for low IQ:
Copy (or put) the "CharData" Folder and paste it (or put it), where the main .exe is!